<template>
  <div class="coupon">
    <div class="img">
      <img :src="src" alt @click="receive">
    </div>
    <div class="receiveSuccess" v-if="successShow">
      <div class="bg"></div>
      <div class="content2" v-show="isInput">
        <div class="tit">优惠券领取</div>

        <input class="input" v-model="mobile" type="number" placeholder="输入手机号">

        <div class="bottom" @click="submit">立即领取</div>
        <span class="close" @click="closeInput"></span>
      </div>
      <div class="content" v-show="!isInput">
        <div class="img">
          <img :src="require('../assets/success.png')" alt>
        </div>
        <p>领取成功,下单抽好礼</p>
        <div class="bottom" @click="ok">确定</div>
      </div>
    </div>
    <div v-if="showBack">
      <div v-if="!isuse" @click="receive" class="bottom_fixed" style="background:#e63535">
        <span style="font-size:0.48rem;font-weight:700;">领取起名优惠券</span>
      </div>
      <div v-else @click="back" class="bottom_fixed">
        <img :src="require('../assets/back.png')" alt>
        <span>领取成功，返回下单抽好礼</span>
      </div>
    </div>
  </div>
</template>
<script>
import http from "../service";
export default {
  data() {
    return {
      successShow: false,
      src: require("../assets/coupon.png"),
      isInput: false,
      mobile: "",
      showBack: true,
      isuse: false
    };
  },
  created() {
    if (!!localStorage.getItem("coupon")) {
      this.src = require("../assets/coupon_r.png");
      this.isuse = true;
    }
    function getQueryString(name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
      var r = window.location.search.substr(1).match(reg);
      if (r != null) return unescape(r[2]);
      return null;
    }
    if (getQueryString("order_sn")) {
      this.showBack = false;
    }
  },
  methods: {
    back() {
      function getQueryString(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]);
        return null;
      }
      if (getQueryString("type")) {
        history.go(-1);
      } else {
        location.href = "https://qiming.yw11.com/newqiming";
      }
    },
    ok() {
      console.log(1);
      this.successShow = false;
    },
    submit() {
      var myreg = /^[1][3,4,5,6,7,8,9][0-9]{9}$/;
      if (!myreg.test(this.mobile)) {
        alert("请输入正确手机号码");
        return;
      }
      http
        .duanwu({
          mobile: this.mobile
        })
        .then(res => {
          if (res.data.code == 1) {
            this.isInput = false;
            localStorage.setItem("coupon", this.mobile);
            this.src = require("../assets/coupon_r.png");
            this.isuse = true;
          } else {
            alert(res.data.msg);
          }
        });
    },
    closeInput() {
      this.successShow = false;
      this.isInput = false;
    },
    receive() {
      if (!localStorage.getItem("coupon")) {
        this.successShow = true;
        this.isInput = true;
      }
    }
  }
};
</script>

<style lang="less" scoped>
.coupon {
  padding-bottom: 0.82rem;
  .img {
    width: 4.64rem;
    height: 1.88rem;
    margin: 0 auto;
    img {
      width: 100%;
      height: 100%;
    }
  }
  .receiveSuccess {
    .bg {
      position: fixed;
      left: 0;
      top: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.6);
      z-index: 10;
    }
    .content2 {
      width: 6.2rem;
      height: 3.84rem;
      border-radius: 0.06rem;
      position: fixed;
      left: 50%;
      top: 50%;
      margin-top: -1.92rem;
      margin-left: -3.1rem;
      background: #fff;
      z-index: 11;
      .tit {
        height: 1rem;
        text-align: center;
        line-height: 1rem;
        color: #fff;
        background: #332d2d;
        font-size: 0.4rem;
        margin-bottom: 0.4rem;
      }
      .input {
        display: block;
        width: 5.4rem;
        height: 0.9rem;
        margin: 0 auto;
        background: #f1f1f1;
        border-radius: 0.06rem;
        margin-bottom: 0.2rem;
        padding: 0 0.2rem;
      }
      .bottom {
        display: block;
        height: 0.9rem;
        width: 5.4rem;
        margin: 0 auto;
        line-height: 0.9rem;
        background: #ec4937;
        border-radius: 0.06rem;
        font-size: 0.28rem;
        color: #fff;
        text-align: center;
      }
      .close {
        width: 0.7rem;
        height: 0.7rem;
        position: absolute;
        background: url("../assets/xx.png") no-repeat;
        background-size: 100%;
        left: 50%;
        margin-left: -0.35rem;
        bottom: -0.9rem;
      }
    }
    .content {
      width: 3.72rem;
      height: 2.8rem;
      border-radius: 0.06rem;
      position: fixed;
      left: 50%;
      top: 50%;
      margin-top: -1.4rem;
      margin-left: -1.86rem;
      background: #fff;
      z-index: 11;
      padding-top: 0.2rem;
      .img {
        width: 1rem;
        height: 1rem;
      }
      .input {
        padding: 0.15rem;
        input {
          border: 1px solid #ccc;
          padding: 0.2rem;
          width: 3.4rem;
        }
      }
      p {
        text-align: center;
        line-height: 1rem;
        color: #999;
        font-size: 0.3rem;
      }
      .bottom {
        position: absolute;
        left: 0;
        bottom: 0;
        height: 0.8rem;
        background: #fdfdfd;
        width: 100%;
        border-top: 1px solid #efefef;
        border-radius: 0 0 0.06rem 0.06rem;
        line-height: 0.8rem;
        text-align: center;
        font-size: 0.34rem;
      }
    }
  }
  .bottom_fixed {
    img {
      width: 0.4rem;
      height: 0.4rem;
      margin-right: 0.1rem;
      position: relative;
      top: 0.05rem;
    }
    position: fixed;
    z-index: 1;
    bottom: 0;
    left: 0;
    background: #71984e;
    text-emphasis: none;
    height: 1.2rem;
    width: 100%;
    line-height: 1.2rem;
    text-align: center;
    font-size: 0.4rem;
    color: #fff;
    box-shadow: 1px 0 2px rgba(0, 0, 0, 0.5);
  }
}
</style>


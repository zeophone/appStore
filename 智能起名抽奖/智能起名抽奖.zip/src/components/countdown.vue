<template>
  <div class="countdown">
      <span class="text">结束倒计时</span>
      <span class="time">{{this.h}}</span>
      <span class="time">{{this.m}}</span>
      <span class="time">{{this.s}}</span>
  </div>
</template>
<script>
export default {
  data() {
    return {
      h: "00",
      m: "00",
      s: "00"
    };
  },
  created() {
    setInterval(() => {
      this.interval();
    }, 1000);
  },
  methods: {
    interval() {
      //活动结束时间
      var stringTime = "2019-6-10 23:59:59";
      //获取即时时间的对象
      var now = new Date();
      //获取结束时间的对象
      var end = new Date(stringTime);
      //获取即时的时间戳
      var nowTimeStamp = now.getTime();
      //获取活动结束的时间戳
      var endTimeStamp = end.getTime();
      //活动剩余秒数，js的时间戳是毫秒级别的
      var remainSecond = (endTimeStamp - nowTimeStamp) / 1000;
      if (remainSecond < 0) remainSecond = 0;
      //剩余的秒数等于days+hours+minutes+seconds
      var oneHour = 60 * 60;
      var oneMinute = 60;

      var Hours = parseInt(remainSecond / oneHour);
      var Minutes = parseInt((remainSecond - Hours * oneHour) / oneMinute);
      var seconds = parseInt(
        remainSecond - (Hours * oneHour + Minutes * oneMinute)
      );
    //补零
      if (Hours < 10) {
        this.h = "0" + Hours;
      } else if(Hours > 99){
          this.h= '99'
      } else{
        this.h = "" + Hours;
      }
      if (Minutes < 10) {
        this.m = "0" + Minutes;
      } else {
        this.m = "" + Minutes;
      }
      if (seconds < 10) {
        this.s = "0" + seconds;
      } else {
        this.s = "" + seconds;
      }
    }
  }
};
</script>
<style lang="less" scoped>
.countdown{
    height: 0.58rem;
    line-height: 0.58rem;
    padding-left: 1.96rem;
    color: #557240;
    font-weight: bold;
    padding-bottom: 2.5rem;
    display: flex;
    .text{
        font-size: 0.24rem;
        margin-right: 0.3rem;
    }
    .time{
        flex-shrink: 0;
        width: 0.66rem;
        height: 0.58rem;
        font-size: 0.30rem;
        letter-spacing: 0.1rem;
        box-sizing: border-box;
        text-align: center;
        margin-right: 0.14rem;
    }
}
</style>

module.exports = {
    publicPath: './',
    // devServer: {
    //     proxy: {
    //         '/api': {
    //             target: 'http://test.yw11.com',
    //             changeOrigin: true,
    //             ws: true,
    //             pathRewrite: {
    //                 '^/api': '/api'
    //             }
    //         }
    //     }
    // }
}

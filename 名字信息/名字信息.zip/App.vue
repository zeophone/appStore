<script>
	export default {
		onLaunch: function() {
		}
	}
</script>

<style lang="scss">
uni-page-body{height: 100%;}
</style>
